package com.touchmenotapps.radialdemo.clickabletoast;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import com.touchmenotapps.radialdemo.R;

public class KKClickableToast {

    public static final int LENGTH_SHORT = 1500;
    public static final int LENGTH_LONG = 3000;

    private static KKClickableToast toast;
    private Handler mHandler;
    private int mDuration;
    private Dialog dialog;

    private KKClickableToast(Context context, View contentView) {
        try {
            mHandler = new Handler();
            dialog = new Dialog(context, R.style.XToastDialogStyle);
            dialog.setContentView(contentView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
    public static void makeToast(Context context, View contentView, int duration) {
        toast = new KKClickableToast(context, contentView);
        toast.mDuration = duration;
        toast.show();
    }
 
    public void show() {
        try {
            if (!dialog.isShowing()) {
                dialog.show();
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = WindowManager.LayoutParams.WRAP_CONTENT;
                params.height = WindowManager.LayoutParams.WRAP_CONTENT;
                params.gravity = Gravity.TOP;
                // 拥有穿透效果 dialog布局之外可以相应事件传递
                params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.getWindow().setDimAmount(0f);
                dialog.getWindow().setAttributes(params);
            }

            mHandler.removeCallbacks(toastTimerRunnable);
            mHandler.postDelayed(toastTimerRunnable, mDuration);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Runnable toastTimerRunnable = new Runnable() {
        @Override
        public void run() {
            if (dialog != null) {
                dialog.dismiss();
            }
            toast = null;
        }
    };
}