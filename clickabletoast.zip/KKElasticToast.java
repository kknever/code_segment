package com.touchmenotapps.radialdemo.clickabletoast;

import android.app.Dialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.touchmenotapps.radialdemo.R;

public class KKElasticToast {
 
    public static final int LENGTH_SHORT = 1500;
    public static final int LENGTH_LONG = 3000;

    private static KKElasticToast toast;
    private final LinearLayout layout;
    private final MyHandler mHandler;
    private int mDuration;
    private final Dialog dialog;
 
    private KKElasticToast(Context context, View contentView) {
        mHandler = new MyHandler(context);
        dialog = new Dialog(context, R.style.XToastDialogStyle);
        layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        dialog.setContentView(layout);
    }

    public static KKElasticToast makeToastOnGoing(Context context, View contentView) {
        if (toast == null) {
            toast = new KKElasticToast(context, contentView);
        }
        toast.mDuration = -1;
        toast.show(contentView);
        return toast;
    }

    public static void makeToast(Context context, View contentView, int duration) {
        if (toast == null) {
            toast = new KKElasticToast(context, contentView);
        }
        toast.mDuration = duration;
        toast.show(contentView);
    }
 
    private void show(View v) {
        try {
            v.setTag(System.currentTimeMillis());
            layout.addView(v);
            if (!dialog.isShowing()) {
                dialog.show();
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                params.width = WindowManager.LayoutParams.WRAP_CONTENT;
                params.height = WindowManager.LayoutParams.WRAP_CONTENT;
                params.gravity = Gravity.TOP;
                params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.getWindow().setDimAmount(0f);
                dialog.getWindow().setAttributes(params);
            }
            mHandler.postDelayed(toastItemTimerRunnable, 2000L);
            if (mDuration > 0) {
                mHandler.removeCallbacks(toastTimerRunnable);
                mHandler.postDelayed(toastTimerRunnable, mDuration);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dismiss() {
        mHandler.removeCallbacks(toastItemTimerRunnable);
        if (layout != null) {
            layout.removeAllViews();
        }
        if (dialog != null) {
            dialog.dismiss();
        }
        toast = null;
    }

    private final Runnable toastTimerRunnable = new Runnable() {
        @Override
        public void run() {
            dismiss();
        }
    };

    private final Runnable toastItemTimerRunnable = new Runnable() {
        @Override
        public void run() {
            if (layout != null) {
                int count = ((ViewGroup) layout).getChildCount();
                if (count <= 1) {
                    return;
                }
                for (int i = 0; i < count; i++) {
                    View child = ((ViewGroup) layout).getChildAt(i);
                    System.out.println("PushToast child: " + i);
                    long ts = 0;
                    try {
                        ts = (long) child.getTag();
                    } catch (Exception ignored) {}
                    if (System.currentTimeMillis() - ts > 2000L) {
                        layout.removeView(child);
                    }
                }
            }
        }
    };
}