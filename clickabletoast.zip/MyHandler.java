package com.touchmenotapps.radialdemo.clickabletoast;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

import java.lang.ref.WeakReference;

public class MyHandler extends Handler {

    //弱引用持有Part8HandlerActivity , GC 回收时会被回收掉
    private WeakReference<Context> weakReference;

    public MyHandler(Context activity) {
        this.weakReference = new WeakReference(activity);
    }

    @Override
    public void handleMessage(Message msg) {
        Context context = weakReference.get();
        super.handleMessage(msg);
        if (null != context) {
        }
    }
}