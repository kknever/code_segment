<style name="XToastDialogStyle"  parent="ThemeOverlay.AppCompat.Dialog">
	<item name="android:windowFrame">@null</item>
	<item name="android:windowNoTitle">true</item>
	<item name="android:background">@android:color/transparent</item>
	<item name="android:windowBackground">@android:color/transparent</item>
	<item name="android:windowIsFloating">true</item>
	<item name="android:windowContentOverlay">@null</item>
	<item name="android:backgroundDimEnabled">false</item>
</style>


val customView: View = LayoutInflater.from(context).inflate(R.layout.toast_layout, null)
customView.findViewById<ImageView>(R.id.iv_icon).setOnClickListener {
	L.d(TAG, "Click VIew....... " + content)
}

customView.findViewById<ImageView>(R.id.iv_close).setOnClickListener {
	toast?.dismiss()
}
//XToast.makeToast(context, customView, XToast.LENGTH_SHORT)
toast = KKElasticToast.makeToastOnGoing(context, customView)
